// Effectuer une requête pour récupérer des données
fetch('https://api.example.com/data') // 1. Envoie une requête GET à l'URL spécifiée
    .then(response => {
        // 2. Vérifie si la réponse est un succès (code HTTP entre 200 et 299)
        if (!response.ok) {
            // Si ce n’est pas le cas, on lève une erreur avec le code HTTP
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        // 3. Transforme le contenu de la réponse en JSON
        return response.json();
    })
    .then(data => {
        // 4. Manipule les données reçues sous forme d'objet JavaScript
        console.log(data); // Affiche les données dans la console
    })
    .catch(error => {
        // 5. Capture et affiche les erreurs, qu'elles soient dues à une requête échouée ou un problème réseau
        console.error('Erreur lors de la requête :', error);
    });

    _____________________________________________________________________________________________________________________

    // Effectuer une requête POST avec un corps JSON
fetch('https://api.example.com/login', { // 1. Envoie une requête POST à l'URL spécifiée
    method: 'POST', // 2. Spécifie la méthode HTTP : POST
    headers: { 
        'Content-Type': 'application/json', // 3. Indique que les données envoyées sont au format JSON
        'Authorization': 'Bearer token123' // 4. Ajoute un en-tête d'autorisation
    },
    body: JSON.stringify({ // 5. Transforme les données JavaScript en une chaîne JSON pour l’envoi
        username: 'user', // Nom d’utilisateur
        password: 'pass'  // Mot de passe
    })
})
    .then(response => {
        // 6. Vérifie si la réponse est un succès
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        return response.json(); // 7. Transforme la réponse en JSON
    })
    .then(data => {
        // 8. Manipule les données reçues après l’envoi
        console.log('Réponse du serveur :', data); // Affiche la réponse du serveur
    })
    .catch(error => {
        // 9. Gère les erreurs et les affiche dans la console
        console.error('Erreur :', error);
    });

    _____________________________________________________________________________________________________________________

    // Fonction pour récupérer des données avec async/await
async function fetchData() {
    try {
        const response = await fetch('https://api.example.com/data'); // 1. Envoie une requête GET
        if (!response.ok) { // 2. Vérifie si la réponse est un succès
            throw new Error(`Erreur HTTP : ${response.status}`); // Lève une erreur si le statut n'est pas OK
        }
        const data = await response.json(); // 3. Transforme la réponse en JSON
        console.log(data); // 4. Affiche les données dans la console
    } catch (error) {
        console.error('Erreur lors de la requête :', error); // 5. Capture et affiche les erreurs
    }
}

// Appel de la fonction
fetchData(); // 6. Appelle la fonction pour récupérer les données
_____________________________________________________________________________________________________________________

// Fonction pour effectuer une requête avec un timeout
async function fetchWithTimeout(url, timeout = 5000) {
    // 1. Crée une promesse pour gérer le timeout
    const controller = new AbortController(); // Permet d'annuler une requête
    const id = setTimeout(() => controller.abort(), timeout); // Déclenche l'annulation après `timeout` ms

    try {
        const response = await fetch(url, { signal: controller.signal }); // 2. Passe le signal d'annulation à fetch
        clearTimeout(id); // 3. Annule le timeout si la réponse est reçue
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        return await response.json(); // 4. Transforme la réponse en JSON
    } catch (error) {
        if (error.name === 'AbortError') {
            console.error('Requête annulée en raison du timeout');
        } else {
            console.error('Erreur :', error);
        }
    }
}

// Appel de la fonction avec un timeout de 3 secondes
fetchWithTimeout('https://api.example.com/data', 3000);
