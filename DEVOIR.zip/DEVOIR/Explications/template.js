// Fonction pour ajouter dynamiquement des cartes à partir du template
function ajouterCartes() {
    // 1. Sélectionne le conteneur où les cartes seront insérées
    const gridContainer = document.getElementById('grid-container');

    // 2. Sélectionne le contenu du template
    const cardTemplate = document.getElementById('card-template').content;

    // 3. Exemple de données pour les cartes
    const cartes = [
        { nom: 'Carte 1', image: 'images/carte1.png' },
        { nom: 'Carte 2', image: 'images/carte2.png' },
        { nom: 'Carte 3', image: 'images/carte3.png' }
    ];

    // 4. Parcourt chaque carte dans les données
    cartes.forEach(carte => {
        // 5. Clone le contenu du template (profond = true pour inclure tous les enfants)
        const cardClone = cardTemplate.cloneNode(true);

        // 6. Modifie les éléments du clone
        cardClone.querySelector('.card-img').src = carte.image; // Définit l'URL de l'image
        cardClone.querySelector('.card-text').textContent = carte.nom; // Définit le texte de la carte

        // 7. Ajoute le clone au conteneur
        gridContainer.appendChild(cardClone);
    });
}

// Appelle la fonction pour insérer les cartes
ajouterCartes();
____________________________________________________________________________________________________________________

async function ajouterCartesDepuisAPI() {
    const gridContainer = document.getElementById('grid-container');
    const cardTemplate = document.getElementById('card-template').content;

    try {
        // Appel à l'API pour récupérer des données
        const response = await fetch('https://api.example.com/cartes');
        const data = await response.json(); // Convertit la réponse en JSON

        data.forEach(carte => {
            const cardClone = cardTemplate.cloneNode(true);
            cardClone.querySelector('.card-img').src = carte.image;
            cardClone.querySelector('.card-text').textContent = carte.nom;
            gridContainer.appendChild(cardClone);
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des données :', error);
    }
}

// Appelle la fonction pour récupérer les données et afficher les cartes
ajouterCartesDepuisAPI();
