// Fonction principale pour afficher les cartes de Magic The Gathering
async function afficherCartes() {
    // Définition de l'URL de base pour récupérer les cartes
    // On utilise l'API Scryfall pour récupérer les cartes du set "Lord of the Rings" en français
    const baseUrl = "https://api.scryfall.com/cards/search?q=e:ltr+lang:fr&format=json&order=set&unique=prints";
    
    // Variable pour parcourir les différentes pages de résultats
    let url = baseUrl; // La première URL pointe vers la page initiale des résultats

    // Sélection des éléments HTML dans lesquels on va insérer les cartes
    const gridContainer = document.getElementById("grid-container"); // Conteneur principal pour afficher les cartes
    const cardTemplate = document.getElementById("card-template"); // Template HTML pré-déclaré pour représenter chaque carte

    // Tableau pour stocker tous les noms des cartes récupérées
    const nomsCartes = [];

    // Récupération des symboles de mana (via une fonction séparée)
    // Les symboles de mana seront utilisés pour afficher les coûts de chaque carte
    const symboles = await getSymbols();

    try {
        // Boucle pour parcourir toutes les pages de résultats de l'API
        // L'API peut avoir plusieurs pages, et on doit les récupérer une par une
        do {
            // Envoie une requête HTTP GET pour récupérer les données de l'API
            const response = await fetch(url); // `fetch` envoie la requête et attend une réponse
            const data = await response.json(); // On transforme la réponse JSON en un objet utilisable

            // Boucle sur chaque carte retournée dans les données de la réponse
            data.data.forEach(card => {
                // Ajoute le nom de la carte récupérée au tableau des noms
                nomsCartes.push(card.printed_name);

                // Clone le template HTML pour générer une carte à afficher
                const newCard = cardTemplate.content.cloneNode(true); // On copie la structure définie dans le <template>

                // Mise à jour de l'image de la carte
                const imgElement = newCard.querySelector(".card-img"); // Sélectionne l'image dans le template
                imgElement.src = card.image_uris.normal; // Associe l'URL de l'image de la carte
                imgElement.alt = card.printed_name; // Ajoute une description alternative (texte) pour l'accessibilité

                // Mise à jour du titre de la carte
                const textElement = newCard.querySelector("p"); // Sélectionne l'élément texte (balise <p>)
                textElement.textContent = card.printed_name; // Insère le nom de la carte en tant que contenu texte

                // Si la carte possède un coût en mana (non nul), on l'ajoute sous son nom
                if (card.mana_cost) {
                    const manaContainer = document.createElement("div"); // Crée un conteneur pour les symboles de mana
                    manaContainer.classList.add("mana-container"); // Ajoute une classe CSS pour le style

                    // Parse le coût de mana de la carte pour extraire chaque symbole
                    const manaSymbols = parseMana(card.mana_cost); // Extrait des symboles individuels

                    manaSymbols.forEach(symbol => {
                        // Pour chaque symbole, on crée un élément <img> qui affichera le symbole
                        const img = document.createElement("img");
                        img.src = symboles[symbol]; // Associe le symbole à son URL (via le dictionnaire de `getSymbols`)
                        img.alt = symbol; // Définit un texte alternatif pour l'image
                        img.classList.add("mana-symbol"); // Ajoute une classe CSS pour le style des symboles
                        manaContainer.appendChild(img); // Ajoute le symbole au conteneur
                    });

                    // Insère le conteneur des symboles de mana dans la carte
                    newCard.querySelector(".card").appendChild(manaContainer);
                }

                // Ajoute la carte complète (image, nom et symboles) au conteneur principal
                gridContainer.appendChild(newCard);
            });

            // Vérifie si l'API indique qu'il y a d'autres pages de résultats
            // `data.has_more` est un booléen qui vaut true si une autre page existe
            url = data.has_more ? data.next_page : null; // Si une autre page existe, on met à jour `url` avec la page suivante
        } while (url); // Répète la boucle tant qu'il y a une URL valide (autre page)

        // Une fois toutes les cartes récupérées, affiche le nombre total dans la console
        console.log(`Nombre total de cartes récupérées : ${nomsCartes.length}`);
    } catch (error) {
        // En cas d'erreur (par exemple, problème de connexion ou API indisponible), on l'affiche dans la console
        console.error("Une erreur s'est produite lors de la récupération des cartes :", error);
    }
}

// Fonction pour récupérer les symboles de mana et leurs URL
// Ces symboles sont essentiels pour afficher les coûts des cartes
async function getSymbols() {
    const url = "https://api.scryfall.com/symbology"; // URL de l'API pour les symboles de mana

    try {
        // Envoie une requête à l'API pour récupérer tous les symboles de mana
        const response = await fetch(url); // Envoie une requête HTTP GET
        const data = await response.json(); // Convertit la réponse JSON en objet JavaScript

        const symbolsMap = {}; // Dictionnaire vide pour associer chaque symbole à son URL
        data.data.forEach(symbol => {
            symbolsMap[symbol.symbol] = symbol.svg_uri; // Remplit le dictionnaire (clé : symbole, valeur : URL)
        });

        return symbolsMap; // Retourne le dictionnaire complet
    } catch (error) {
        // Affiche une erreur dans la console en cas de problème avec l'API
        console.error("Erreur lors de la récupération des symboles de mana :", error);
        return {}; // Retourne un dictionnaire vide si une erreur se produit
    }
}

// Fonction pour extraire les symboles de mana depuis une chaîne de caractères
// Exemple : transforme "{2}{W}{W}" en ["{2}", "{W}", "{W}"]
function parseMana(manaCost) {
    const regex = /{.*?}/g; // Expression régulière pour capturer les symboles entre accolades
    return manaCost.match(regex) || []; // Retourne un tableau des symboles ou un tableau vide si aucun symbole trouvé
}

// Événement exécuté lorsque la page HTML est entièrement chargée
// On attend que le DOM soit prêt avant d'exécuter la fonction principale
document.addEventListener("DOMContentLoaded", afficherCartes);


//async function afficherCartes() {
//    const url = "https://api.scryfall.com/cards/search?q=e:ltr+lang:fr&format=json&order=set&unique=prints";
//    let cartes = [];
//    let nextPage = url;

//    const container = document.querySelector(".grid-container");

//    try {
//        while (nextPage) {
//            const response = await fetch(nextPage);
//            const data = await response.json();
//            cartes = cartes.concat(data.data);
//            nextPage = data.has_more ? data.next_page : null;
//        }

        // Parcourir les cartes et les insérer dans le DOM
//        cartes.forEach(carte => {
//            const template = document.querySelector("#card-template").content.cloneNode(true);
//            template.querySelector(".card-title").textContent = carte.printed_name || "Nom inconnu";
//            template.querySelector(".card-image").src = carte.image_uris?.normal || "";
//            container.appendChild(template);
//        });
        
//        console.log(`Nombre total de cartes récupérées : ${cartes.length}`);
//    } catch (error) {
//        console.error("Erreur lors de la récupération des cartes :", error);
//    }
//}
