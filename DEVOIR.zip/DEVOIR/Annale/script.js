async function afficherCartes() {
    const response = await fetch('https://api.scryfall.com/cards/search?q=e:ltr+lang:fr&format=json&order=set&unique=prints');
    let data = await response.json();

    const gridContainer = document.querySelector('.grid-container');

    data.data.forEach(card => {
        const cardDiv = document.createElement('div');
        cardDiv.className = 'card';

        const img = document.createElement('img');
        img.src = card.image_uris?.normal || 'images/placeholder.jpg';
        img.alt = card.printed_name || 'Carte sans nom';

        const title = document.createElement('p');
        title.textContent = card.printed_name || 'Carte sans nom';

        cardDiv.appendChild(img);
        cardDiv.appendChild(title);
        gridContainer.appendChild(cardDiv);
    });
}

document.addEventListener('DOMContentLoaded', afficherCartes);
